package restaurante;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
/**
 *
 * @author Emilio y Pablo
 */
public class Restaurante {
    
    public static Scanner lector = new Scanner(System.in);
//    public static Scanner lector = new Scanner(System.in);
    /**
     * Creamos una funcion cuyo objetivo es imprimir el menú de camarero, para ello creamos un do while para imprimir el menu y dentro del switch dentro de cada
     * opción llamamos a la función que realiza lo que pone el titulo del numero.
     * @param lectorfichero
     * @param listamesas
     * @param taulesfit 
     */
    public static void menuCamarero(Scanner lectorfichero, ArrayList listamesas, File taulesfit) {
        boolean salir = false;
        do {
            int i = 0;
            while (i < 1 || i > 5) {
                System.out.println("Pulsa cualquier tecla para continuar...");
                String x = lector.nextLine();
                System.out.println("MENU CAMBRER");
                System.out.println("--------");
                System.out.println("1 - Generar mesa");
                System.out.println("2 - Borrar mesa");
                System.out.println("3 - Listar mesas");
                System.out.println("4 - Modificar mesa");
                System.out.println("5 - Cerrar sesion");
                System.out.println("Selecciona la opción: ");
                i = lector.nextInt();
            }
            switch (i) {
                case 1:
                    insertarmesa(taulesfit);
                    break;

                case 2:
                    Borrarmesa(taulesfit);                    
                    break;
                case 3:
                    listarmesas(listamesas);
                    break;
                case 4:
                    Modificarmesa(taulesfit)
                    break;
                case 5:
                    salir = false;
                    break;
            }
        } while (salir = true);
    }
    /**
    * Creamos una función llamada menu Administrador que lo que hace es mostrar el menu de Administrador. Para ello hacemos como en el menu de camarero , hacemos el menu utilizando
    * un do while y con el switch, y dentro del switch en cada opcion llamamos a la funcion correspondiente.
    * @param empleados
    * @param taulesfit 
    */
    public static void menuAdministrador(Empleados[] empleados) {
        boolean salir = false;
        do {
            int i = 0;
            while (i < 1 || i > 5) {
                System.out.println("MENU ADMINISTRADOR");
                System.out.println("--------");
                System.out.println("1 - Generar Camarero");
                System.out.println("2 - Borrar Camarero");
                System.out.println("3 - Listar Usuarios");
                System.out.println("4 - Modificar Camarero");
                System.out.println("5 - Cerrar sesion");
                System.out.println("Selecciona la opción: ");
                i = lector.nextInt();
            }
            switch (i) {
                case 1:
                    insertarcamarero(empleados);
                    break;

                case 2:
                    //borrarcamarero();                    
                    break;
                case 3:
                    //listarcamarero();
                    break;
                case 4:
                    //modificarcamarero();
                    break;
                case 5:
                    salir = false;
                    break;
            }
        } while (salir = true);
    }
    /**
     * La función eliminar mesa el objetivo es que podamos eleminar una mesa, para ello le pasamos el parametro de taulesfit que es el fichero.
     * 
     * @param taulesfit 
     */
    public static void Borrarmesa(File taulesfit){
        Scanner lector = new Scanner (System.in);
       
       
        System.out.println("Escribe la id que quiere eliminar: ");
        String liniaeliminada = lector.nextLine();
       
        //Array que guarda todas las lineas leidas del fichero
       
        ArrayList<String> lineas = new ArrayList<>();
       
        //Abrimos fichero de texto para leerlo en memoria
       
        try{
            Scanner lectorFichero = new Scanner (taulesfit);
           
            while (lectorFichero.hasNext()){
                lineas.add(lectorFichero.nextLine());
            }
            lectorFichero.close();
           
        }catch (Exception e){
            System.out.println("Ha ocurrido un error al abrir/leer el fichero");
        }
       
        //Abrimos el fichero de texto para sobreescribirlo
        try{
            FileWriter writer = new FileWriter(taulesfit);
           
            for (String linea: lineas){
                if(!liniaeliminada.equals(linea.substring(0,7))){
                    writer.write(linea + "\n");
                }
            }
            writer.close();
        }catch  (Exception e){
            System.out.println("Ha ocurrido un error al abrir/sobreescribir el fichero");
        }
       
    }
    /**
     * Esta función lo que hace es pedir el nombre de la mesa que hay que modificar y directamente borra la linea y la sobreescribe, para ello recibe el parametro de taulesfit
     * @param taulesfit 
     */
    public static void Modificarmesa(File taulesfit){
        System.out.println("Escribe el id de la mesa que quieres modificar, siguiendo el formato => taula01");
        String liniamodificada = lector.next();
        
        ArrayList<String> lineas = new ArrayList<>();
        
        try{
            Scanner lectorFichero = new Scanner (taulesfit);
            
            while (lectorFichero.hasNext()){
                lineas.add(lectorFichero.nextLine());
            }
            lectorFichero.close();
        }catch (Exception e){
            System.out.println("Ha ocurrido un error al abrir/leer el fichero");
        }
        
        try{
            FileWriter writer = new FileWriter(taulesfit);
            
            for (String linea: lineas){
                if(liniamodificada.equals(linea.substring(0,7))){ //Aqui buscamos la linea y la vamos comparando con la mesa que queremos modificar
                    writer.write(pedirdatos()); //Esto lo que hace es que sobreescribe la linea llamando a la función de pedirdatos.
                }else {
                    writer.write("\n" + linea);
                }
            }
            writer.close();
        }catch (Exception e){
                    System.out.println("Ha ocurrido un error al abrir/sobreescribir el fichero");}

    }
    /**
     * Esta función lo que hace es insertar una mesa nueva en el fichero txt
     * @param taulesfit 
     */
    public static void insertarmesa(File taulesfit){
        try{
            FileWriter añadir = new FileWriter(taulesfit, true);
            String linea = pedirdatos();
            añadir.write(linea);
            añadir.close();
        } catch (Exception e){
            System.out.println("No se ha podido añadir una mesa");
        }
    }
    /**
     * Esta función lo que hace es ir pidiendo los datos para más tarde poder añadirlos al fichero txt.
     * @return 
     */
    public static String pedirdatos(){
        String nombre, descripcion, niños, ventilador, jardin;
        int capacidad, adultos;
        boolean nenes, venti, jar;
        System.out.print("Dame el nombre de la nueva mesa: ");
        nombre = lector.next();
        System.out.print("Dame la descripcion de la mesa: ");
        descripcion = lector.next();
        System.out.print("Dame la capacidad maxima de personas en la mesa: ");
        capacidad = lector.nextInt();
        System.out.print("Hay sillas de niños en la mesa? ");
        niños = lector.next().toLowerCase();
        nenes = transformar(niños);
        System.out.print("Dame el numero de sillas que hay para adultos: ");
        adultos = lector.nextInt();
        System.out.print("Tiene ventilador? ");
        ventilador = lector.next().toLowerCase();
        venti = transformar(ventilador);
        System.out.print("La mesa está en el jardin? ");
        jardin = lector.next().toLowerCase();
        jar = transformar(jardin);
        String linea = "\n" + nombre + "," + descripcion + "," + capacidad + "," + nenes + "," + adultos + "," + venti + "," + jar;
        return linea;
    }
    /**
     * Esta función lo que hace es permitirnos poner los true o fals independientemente de como escriba el usuario si o no.
     * @param trans
     * @return 
     */
    public static boolean transformar(String trans){
        boolean transform;
        transform = trans.equals("si");
        return transform;
    }
    /**
     * Esto lo que hace es permitirnos listar las mesas.
     * @param listamesas 
     */
    public static void listarmesas(ArrayList listamesas){
        System.out.println(listamesas);
    }
    /**
     * Esta función nos permite generar el archivo .dat de los usuarios 
     * @throws FileNotFoundException
     * @throws IOException 
     */
    public static void generardat () throws FileNotFoundException, IOException{
        try{
            ObjectOutputStream ficherodat = new ObjectOutputStream(new FileOutputStream("C:\\Users\\alumne\\Desktop\\Restaurante\\src\\restaurante\\users.dat"));
            Empleados[] persona = new Empleados[100];
            persona[0] = new Empleados();
            persona[0].user = "admin";
            persona[0].password = "root";
            persona[0].rol = "administrador";

            ficherodat.writeObject(persona);
            ficherodat.close();
        } catch (IOException e) {
            System.out.println("No se ha podido generar el fichero dat");
        }
        
    }
    /**
     * Esta función lo que hace es generar el login para los empleados
     * @param empleados
     * @return 
     */
    public static boolean login(Empleados[] empleados){
        boolean login = false;
        int i = 0;
        String user, password;
        do {
            System.out.print("Introdce el nombre de usuario: ");
            user = lector.nextLine();
            System.out.print("Introdce la password: ");
            password = lector.nextLine();
            for (int x = 0; x < empleados.length; x ++){
                if (user.equals(empleados[x].user) && password.equals(empleados[x].password)){
                    i = 4;
                    login = true;
                }
            }
            if (i != 4)
                System.out.println("Error pruebe otra vez");
        }while(i < 3);
        return login;
    }
    /**
     * Esta función lo que hace es insertar un camarero nuevo en el archivo .dat
     * @param empleados 
     */
    public static void insertarcamarero(Empleados[] empleados){
        String user, password;
        try{
            ObjectOutputStream ficherodat = new ObjectOutputStream(new FileOutputStream("C:\\Users\\alumne\\Desktop\\Restaurante\\src\\restaurante\\users.dat"));
            for (int i = 0; i < empleados.length; i++){
                if (empleados[i] == null){
                    System.out.print("Dame el nombre del nuevo usuario");
                    user = lector.nextLine();
                    System.out.print("Dame la password del nuevo usuario");
                    password = lector.nextLine();
                    empleados[i].user = user;
                    empleados[i].password = password;
                    empleados[i].rol = "camarero";
                    i = 9999;

                }
            }
            ficherodat.writeObject(empleados);

        } catch(Exception e){
            System.out.println("Error al cargar el fichero");
        }
    }
    /**
    Esta funcion nos permite logearnos ya sea como root o camarero
    
     */
    public static int inicio(){
        int op;
        boolean menu = false;
        do{
            System.out.print("Tipos de login: \n1. Root\n2. Camarero");
            System.out.print("\nQue tipo de login quieres realizar? ");
            op = lector.nextInt();
            if (op < 1 || op > 2)
                System.out.println("Opción invalida, por favor escoja una de las siguientes opciones: ");
        } while(menu = false);
        return op;
    }
    
    public static void main(String[] args) throws FileNotFoundException, IOException {
        // Accedemos al fichero tables.txt.txt y lo almacenamos en taulesfit.
        File taulesfit = new File("C:\\Users\\alumne\\Desktop\\Restaurante\\src\\restaurante\\tables.txt.txt");
        Scanner lectorfichero = new Scanner(taulesfit, "ISO-8859-1");

        ArrayList<String> listamesas = new ArrayList<>();
        //Recorremos el fichero y lo almacenamos en el Array dinámico Listamesas
        try {
            while (lectorfichero.hasNext()) {
                listamesas.add(lectorfichero.nextLine());
            }

            lectorfichero.close();
        } catch (Exception e) {
            System.out.println("Ha ocurrido un error al abrir/leer el fichero");
        }
        //Inicializamos la clase empleados
        Empleados[] empleados = null;
        //Inicializamos el objeto ficherodat
        ObjectInputStream ficherodat = null;
        //LLamamos a la función para generar el fichero de los usuarios .dat
        generardat();

        try {
            //Accedemos al fichero .dat y lo almacenamos en el fichero dat
            ficherodat = new ObjectInputStream(new FileInputStream("C:\\Users\\alumne\\Desktop\\Restaurante\\src\\restaurante\\users.dat"));
            //Almacenamos en la clase empleados el conetenido de ficherodat
            empleados = (Empleados[]) ficherodat.readObject();
            ficherodat.close();
            
        } catch (Exception e){
            System.out.println("El .dat no ha cargado");
        }
        
        
        //Llamamos a la funcion login y la almacenamos en la variable op para saber si nos logeamos como usuario root o usuario camarero.
        int op = inicio();
        //Aqui definimos si iniciamos como root o como camarero
        if (op == 1){
            boolean login = login(empleados);
            if (login == true){
                menuAdministrador(empleados);
            }
        } else if (op == 2){
            menuCamarero(lectorfichero, listamesas, taulesfit);
        
        }
        
    }

}
