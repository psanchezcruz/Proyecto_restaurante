package restaurante;

import java.io.Serializable;

/**
 *
 * @author Emilio y Pablo
 */
public class Empleados implements Serializable {
    public String user;
    public String password;
    public String rol;
}
